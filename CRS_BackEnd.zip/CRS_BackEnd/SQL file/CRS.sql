use crs;

INSERT INTO `admin` VALUES ('admin@gmail.com','admin','admin@123');

INSERT INTO `engineer` VALUES ('aryan@gmail.com','Aryan','ar@123'),
('harshal@gmail.com','Harshal','ha@123'),
('javeed@gmail.com','javeed','ja@123'),
('kanchan@gmail.com','Kanchan','kan@123'),
('manisha@gmail.com','Manisha','mani@123'),
('niranjan@gmail.com','Niranjan','ni@123'),
('prajakta@gmail.com','Prajakta','pra@123'),
('rajesh@gmail.com','Rajesh','raj@123'),
('rakhi@gmail.com','Rakhi','rak@123'),
('rohit@gmail.com','Rohit','rohi@123');

INSERT INTO `manager` VALUES ('arunita@gmail.com','Arunita','aru@123','123451'),
('canyaman@gmail.com','Canyaman','can@123','123453'),
('prakash@gmail.com','Prakash','pra@123','123450'),
('punith@gmail.com','Punith','puni@123','123454'),
('shahid@gmail.com','Shahid','sha@123','123452');