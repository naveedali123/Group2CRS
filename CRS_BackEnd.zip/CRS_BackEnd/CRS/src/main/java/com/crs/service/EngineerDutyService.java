package com.crs.service;

import com.crs.model.EngineerDuty;

public interface EngineerDutyService {
	void saveEngineerDuty (EngineerDuty engineerDuty);

}
