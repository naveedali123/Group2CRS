package com.crs.service;



public interface  AdminService {
	Boolean validateAdmin(String adminEmail, String adminPassword);
}
