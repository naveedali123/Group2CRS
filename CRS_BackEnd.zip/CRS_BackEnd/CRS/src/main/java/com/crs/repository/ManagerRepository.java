package com.crs.repository;


import org.springframework.data.repository.CrudRepository;

import com.crs.model.Managers;


public interface ManagerRepository extends CrudRepository<Managers, String> {

	

}
