import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Complaints } from './../../models/complaints';
import { AdminService } from './../../services/admin.service';
import { EngineersService } from './../../services/engineers.service';
import { Feedbacks } from './../../models/feedbacks';
import { ComplaintsService } from './../../services/complaints.service';

@Component({
  selector: 'app-engineer-dashboard',
  templateUrl: './engineer-dashboard.component.html',
  styleUrls: ['./engineer-dashboard.component.css'],
})
export class EngineerDashboardComponent implements OnInit {
  updateEngineerStatus: boolean = false;

  anyButtonClicked: boolean = false;

  updateComplaintStatus: boolean = false;

  complaintUpdating: Complaints = new Complaints();

  complaints: Complaints[] = [];

  viewFeedbacksStatus: boolean = false;

  feedbacks: Feedbacks[] = [];

  assignEngineersButton: boolean = true;
  assignEngineersDropdown: boolean = false;
  engineerEmails: string[] = [];
  selectedStatus: string;
  data: any;

  constructor(
    private _adminService: AdminService,
    private router: Router,
    private _engineersService: EngineersService,
    private _complaintsService: ComplaintsService
  ) {
    this.data = JSON.parse(sessionStorage.getItem('loggedUser')!);
  }

  ngOnInit(): void {
    this.viewFeedbacks();
    this.getAllComplaintsByEmails();
  }

  viewFeedbacks() {
    this.viewFeedbacksStatus = true;
    this.anyButtonClicked = true;
    this._adminService.getAllFeedbacks().subscribe((data) => {
      this.feedbacks = data;
    });
  }

  logout() {
    sessionStorage.removeItem('loggedUser');
    this.router.navigateByUrl('');
  }

  statusSelected(event: any) {
    this.selectedStatus = event.target.value;

    console.log(this.selectedStatus);
  }

  getAllComplaintsByEmails() {
    this._complaintsService
      .getAllComplaintsByEngineerEmail(this.data.engineerEmail)
      .subscribe((data) => {
        console.log('data = complaints fetched based on pincode', data);

        this.complaints = data;
      });
  }

  updateComplaint(complaint: Complaints) {
    this.updateEngineerStatus = true;
    this.complaintUpdating = complaint;
  }

  updateStatus() {
    console.log('new status', this.selectedStatus);

    this._engineersService
      .updateStatus(this.complaintUpdating.ticketId, this.selectedStatus)
      .subscribe((data) => {
        console.log('data added successfully', data);
        this.updateEngineerStatus = false;
        this.getAllComplaintsByEmails();
        alert('updated Successfully !');
      });
  }
}
