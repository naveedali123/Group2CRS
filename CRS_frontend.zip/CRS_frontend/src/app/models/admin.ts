export class Admin {
    adminEmail: string;
    adminPassword: string;
    adminName: string;
}
